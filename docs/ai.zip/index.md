# Home - Guía de Implementación para la gestión de citas médicas enfocado en la APS v0.4.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:https://interoperabilidad.minsal.cl/fhir/ig/agenda/ImplementationGuide/hl7.fhir.cl.agenda | *Version*:0.4.0 |
| Draft as of 2025-10-23 | *Computable Name*:Agendacitasmedicas |

### Contexto

Esta guía de implementación es diseñada para el uso de datos enfocados en la Atención Primaria de Salud (APS) para Agenda. 

### Introducción

En las APS solicitar una hora médica es bastaste ineficiente para las personas por lo que con esta guía de implementación esta diseñada paraa un sistema digital que permita gestionar las citas médicas de manera eficiente. Este sistema abarcará la solicitud, confirmación, actualización y consulta de citas médicas.

### Contenido de la Guía

Esta guía de implementación se estructura en base al menú de la parte superior de la siguiente manera: 

* [Index](index.md): Página de Bienvenida a la Guía.
* [Objetivos](Objetivos.md): Información General sobre los objetivos de esta Guía
* [Casos de Uso](CasosDeUsos.md): Información detallada de los casos de uso, sus actores, y la secuencia de transacciones.
* [Seguridad](Seguridad.md): Infromación sobre la seguridad.
* [Resumen de Artefactos](artifacts.md): Describe todos los artefactos que son parte de esta GI, separados en Estructura de Perfiles, Extensiones, Value Sets y Ejemplos. 
 Esta estructura está diseñada para facilitar la navegación y comprensión de los diversos componentes y procesos involucrados en la agenda en la Atención Primaria de Salud.

El codigo fuente de esta Guía de implementación se puede encontrar en [OpenHIE GitHub](https://github.com/openhie/Training-Solution-1).

### Análisis de las versiones cruzadas

This is an R4 IG. None of the features it uses are changed in R4B, so it can be used as is with R4B systems. Packages for both [R4 (hl7.fhir.cl.agenda.r4)](package.r4.tgz) and [R4B (hl7.fhir.cl.agenda.r4b)](package.r4b.tgz) are available.

### Dependency Table





### Globals Table

*There are no Global profiles defined*

### IP Statements

This publication includes IP covered under the following statements.

* HL7 International.

* [Financial Resource Status Codes](http://hl7.org/fhir/R4/codesystem-fm-status.html): [Prevision](StructureDefinition-Prevision.md)


* ISO maintains the copyright on the country codes, and controls its use carefully. For further details see the ISO 3166 web page: [https://www.iso.org/iso-3166-country-codes.html](https://www.iso.org/iso-3166-country-codes.html)

* [ISO 3166-1 Codes for the representation of names of countries and their subdivisions — Part 1: Country code](http://terminology.hl7.org/6.5.0/CodeSystem-ISO3166Part1.html): [Agendacitasmedicas](index.md), [ApellidoServicio](StructureDefinition-ApellidoServicio.md)...Show 21 more,[BundleRespuesta](StructureDefinition-BundleRespuesta.md),[BundleSolicitud](StructureDefinition-BundleSolicitud.md),[CSCategotias](CodeSystem-CSCategotias.md),[CSPrestaciones](CodeSystem-CSPrestaciones.md),[CSPrevision](CodeSystem-CSPrevision.md),[CSServicios](CodeSystem-CSServicios.md),[Cita](StructureDefinition-Cita.md),[CitaRespuesta](StructureDefinition-CitaRespuesta.md),[Edad](StructureDefinition-Edad.md),[Organizacion](StructureDefinition-Organizacion.md),[PacienteAgenda](StructureDefinition-PacienteAgenda.md),[Prestaciones](StructureDefinition-Prestaciones.md),[Prestador](StructureDefinition-Prestador.md),[Prevision](StructureDefinition-Prevision.md),[RolPrestador](StructureDefinition-RolPrestador.md),[Servicios](StructureDefinition-Servicios.md),[SolicitudServicio](StructureDefinition-SolicitudServicio.md),[VSCategorias](ValueSet-VSCategorias.md),[VSPrestaciones](ValueSet-VSPrestaciones.md),[VSPrevision](ValueSet-VSPrevision.md)and[VSServicios](ValueSet-VSServicios.md)


* This material contains content that is copyright of SNOMED International. Implementers of these specifications must have the appropriate SNOMED CT Affiliate license - for more information contact [https://www.snomed.org/get-snomed](https://www.snomed.org/get-snomed) or [info@snomed.org](mailto:info@snomed.org).

* [SNOMED Clinical Terms&reg; (SNOMED CT&reg;)](http://hl7.org/fhir/R4/codesystem-snomedct.html): [Appointment/EjemploCita1](Appointment-EjemploCita1.md), [Appointment/EjemploCita2](Appointment-EjemploCita2.md), [Bundle/BundResp](Bundle-BundResp.md), [Cita](StructureDefinition-Cita.md) and [SolicitudServicio](StructureDefinition-SolicitudServicio.md)


### Intellectual Property Considerations

 Si bien esta guía de implementación y el FHIR subyacente tienen licencia de dominio público, esta guía puede incluir ejemplos que utilicen terminologías como como LOINC, SNOMED CT y otros que tienen requisitos de licencia más restrictivos. Los implementadores deben familiarizarse con las licencias y cualquier otra limitación de terminología, cuestionarios y otros componentes utilizados como parte de su proceso de implementación. En algunos casos, Los requisitos de licencia pueden limitar los sistemas con los que se pueden compartir los datos capturados mediante ciertos cuestionarios. 

### Responsabilidad

 Esta especificación se proporciona sin garantía de integridad o coherencia, y la publicación oficial reemplaza este borrador. No se puede inferir ninguna responsabilidad por el uso o mal uso de esta especificación, o sus consecuencias. 

</div>

**Esta Guía de Implementación ha sido posible gracias a las atentas contribuciones de las siguientes personas:** 

* Valentina Contreras, Tesista
* Cesar Galindo, Profesor Guia
* John Diaz, Co-Guia

